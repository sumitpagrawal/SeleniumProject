package resources;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;
import java.util.concurrent.TimeUnit;
import org.apache.logging.log4j.core.util.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.io.FileHandler;
import org.testng.reporters.Files;

public class base {
	//Creating driver object globally
	public 	static WebDriver driver;
	public Properties prop; 
	
	public WebDriver initializeDriver() throws IOException
	{
		//Creating DataDriven properties file
		 prop = new Properties();
		
		//Give DataDriven File path
		//To create the file in 'main' folder : Go to File> New> Other>File > Data.properties
		//Below path is taken from Properties section
		FileInputStream fis = new FileInputStream("C:\\Users\\Sumit\\E2EProject\\src\\main\\java\\Resources\\Data.properties");
		
		//To connect Data file with Properties
		prop.load(fis);
		String browserName = prop.getProperty("browser");
			//Use 'equals' here as we are comparing the values in the objects, if not used then 'NULL Pointer Exception' will be shown
			// '==' can be used only when both the objects points to the same memory location
			if(browserName.equals("chrome"))
			{
				//execute in chrome
				System.setProperty("webdriver.chrome.driver", "C://chromedriver.exe");
				driver = new ChromeDriver();
			}
			else if(browserName.equals("firefox"))
			{
				//execute in firefox
			}
			
			driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
			return driver;
	}
	
	public void getScreenshot(String result) throws IOException
	{
		File src = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
		FileHandler.copy(src, new File("D://"+result+"screenshot.png"));		
	}
}
